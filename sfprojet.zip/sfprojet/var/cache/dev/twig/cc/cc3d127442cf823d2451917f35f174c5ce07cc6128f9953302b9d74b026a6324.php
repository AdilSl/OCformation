<?php

/* SecondBundle:Default:view1.html.twig */
class __TwigTemplate_a084af4aefa89d61d58a28595bc8b67237d5689f58d779d92e7895d5456c1aed extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SecondBundle:Default:view1.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SecondBundle:Default:view1.html.twig"));

        // line 1
        echo "<html>

<head>

    <title>select</title>

</head>

<body>

<h1>Affichage de la liste des Produit !</h1>


<div>

    ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listProduit"]) || array_key_exists("listProduit", $context) ? $context["listProduit"] : (function () { throw new Twig_Error_Runtime('Variable "listProduit" does not exist.', 16, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["ligne"]) {
            // line 17
            echo "

        <p>/Id produit : ";
            // line 19
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ligne"], "id", array()), "html", null, true);
            echo "  /titre produit :  ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ligne"], "getTitle", array()), "html", null, true);
            echo "    /author produit : ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ligne"], "getAuthor", array()), "html", null, true);
            echo "     </p>

    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ligne'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "
</div>


</body>

</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "SecondBundle:Default:view1.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 22,  54 => 19,  50 => 17,  46 => 16,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<html>

<head>

    <title>select</title>

</head>

<body>

<h1>Affichage de la liste des Produit !</h1>


<div>

    {% for ligne in listProduit %}


        <p>/Id produit : {{ ligne.id }}  /titre produit :  {{ ligne.getTitle }}    /author produit : {{ ligne.getAuthor }}     </p>

    {% endfor %}

</div>


</body>

</html>", "SecondBundle:Default:view1.html.twig", "/var/www/sfprojet/src/Smile/SecondBundle/Resources/views/Default/view1.html.twig");
    }
}
