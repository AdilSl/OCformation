<?php

/* FirstBundle:Advert:form.html.twig */
class __TwigTemplate_0af9008f941ddc301f31b86b8f96d5e415ac403b8dca807c2b7ae41fbe3f03b1 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FirstBundle:Advert:form.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FirstBundle:Advert:form.html.twig"));

        // line 1
        echo "
";
        // line 7
        echo "

<h3>Formulaire d'annonce</h3>


";
        // line 15
        echo "
<div class=\"well\">

    Ici se trouvera le formulaire.

</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "FirstBundle:Advert:form.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  39 => 15,  32 => 7,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("
{# Cette vue n'hérite de personne, elle sera incluse par d'autres vues qui,

   elles, hériteront probablement du layout. Je dis « probablement » car,

   ici pour cette vue, on n'en sait rien et c'est une info qui ne nous concerne pas. #}


<h3>Formulaire d'annonce</h3>


{# On laisse vide la vue pour l'instant, on la comblera plus tard

   lorsqu'on saura afficher un formulaire. #}

<div class=\"well\">

    Ici se trouvera le formulaire.

</div>", "FirstBundle:Advert:form.html.twig", "/var/www/sfprojet/src/Smile/FirstBundle/Resources/views/Advert/form.html.twig");
    }
}
