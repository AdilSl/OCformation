<?php

/* SecondBundle:Default:select.html.twig */
class __TwigTemplate_c44bae70e3188e2e3da71466fca2c198f161b2da7a139995a106c1039e9e739c extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SecondBundle:Default:select.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SecondBundle:Default:select.html.twig"));

        // line 1
        echo "<html>

<head>

    <title>select</title>

</head>

<body>

<h1>Affichage de la liste des Produit !</h1>


<div>

    ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["listeProduit"]) || array_key_exists("listeProduit", $context) ? $context["listeProduit"] : (function () { throw new Twig_Error_Runtime('Variable "listeProduit" does not exist.', 16, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["produit"]) {
            // line 17
            echo "

        <p>/Id produit : ";
            // line 19
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["produit"], "id", array()), "html", null, true);
            echo "  /titre produit :  ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["produit"], "title", array()), "html", null, true);
            echo "    /author produit : ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["produit"], "image", array()), "Url", array()), "html", null, true);
            echo "    / </p>

    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['produit'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "
</div>


<ul class=\"pagination\">

    ";
        // line 29
        echo "
    ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, (isset($context["nbPages"]) || array_key_exists("nbPages", $context) ? $context["nbPages"] : (function () { throw new Twig_Error_Runtime('Variable "nbPages" does not exist.', 30, $this->source); })())));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 31
            echo "
        <li";
            // line 32
            if (($context["p"] == (isset($context["page"]) || array_key_exists("page", $context) ? $context["page"] : (function () { throw new Twig_Error_Runtime('Variable "page" does not exist.', 32, $this->source); })()))) {
                echo " class=\"active\"";
            }
            echo ">

            <a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index", array("page" => $context["p"])), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["p"], "html", null, true);
            echo "</a>

        </li>

    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "
</ul>

</body>

</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "SecondBundle:Default:select.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 39,  92 => 34,  85 => 32,  82 => 31,  78 => 30,  75 => 29,  67 => 22,  54 => 19,  50 => 17,  46 => 16,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<html>

<head>

    <title>select</title>

</head>

<body>

<h1>Affichage de la liste des Produit !</h1>


<div>

    {% for produit in listeProduit %}


        <p>/Id produit : {{ produit.id }}  /titre produit :  {{ produit.title }}    /author produit : {{ produit.image.Url }}    / </p>

    {% endfor %}

</div>


<ul class=\"pagination\">

    {# On utilise la fonction range(a, b) qui crée un tableau de valeurs entre a et b #}

    {% for p in range(1, nbPages) %}

        <li{% if p == page %} class=\"active\"{% endif %}>

            <a href=\"{{ path('index', {'page': p}) }}\">{{ p }}</a>

        </li>

    {% endfor %}

</ul>

</body>

</html>", "SecondBundle:Default:select.html.twig", "/var/www/sfprojet/src/Smile/SecondBundle/Resources/views/Default/select.html.twig");
    }
}
