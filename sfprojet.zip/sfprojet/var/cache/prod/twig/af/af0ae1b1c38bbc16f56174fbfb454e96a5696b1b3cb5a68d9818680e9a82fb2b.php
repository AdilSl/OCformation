<?php

/* FirstBundle:Advert:index.html.twig */
class __TwigTemplate_1557a72272e641610f3afa04a6b221714c9555e82f81c2102323ab37a20e72bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>

<html>

<head>

    <title>Bienvenue sur ma première page avec OpenClassrooms !</title>

</head>

<body>

<h1>Hello ";
        // line 13
        echo twig_escape_filter($this->env, ($context["nom"] ?? null), "html", null, true);
        echo "!</h1>


<p>

    Le Hello World est un grand classique en programmation.<br>

    Il signifie énormément, car cela veut dire que vous avez<br>

    réussi à exécuter le programme pour accomplir une tâche simple :<br>

    afficher ce hello world !<br>
    <lorem></lorem>

</p>

</body>

</html>";
    }

    public function getTemplateName()
    {
        return "FirstBundle:Advert:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 13,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "FirstBundle:Advert:index.html.twig", "/var/www/sfprojet/var/cache/prod/../../../src/Smile/FirstBundle/Resources/views/Advert/index.html.twig");
    }
}
