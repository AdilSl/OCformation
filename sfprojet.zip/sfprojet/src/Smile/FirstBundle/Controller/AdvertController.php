<?php
/**
 * Created by PhpStorm.
 * User: adil
 * Date: 26/11/18
 * Time: 08:38
 */

namespace Smile\FirstBundle\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;


class AdvertController extends Controller

{

    public function indexAction()

    {
        $listAdverts = array(

            array(

                'title'   => 'Recherche développpeur Symfony',

                'id'      => 1,

                'author'  => 'Alexandre',

                'content' => 'Nous recherchons un développeur Symfony débutant sur Lyon. Blabla…',

                'date'    => new \Datetime()),

            array(

                'title'   => 'Mission de webmaster',

                'id'      => 2,

                'author'  => 'Hugo',

                'content' => 'Nous recherchons un webmaster capable de maintenir notre site internet. Blabla…',

                'date'    => new \Datetime()),

            array(

                'title'   => 'Offre de stage webdesigner',

                'id'      => 3,

                'author'  => 'Mathieu',

                'content' => 'Nous proposons un poste pour webdesigner. Blabla…',

                'date'    => new \Datetime())

        );


        // Et modifiez le 2nd argument pour injecter notre liste

        return $this->render('FirstBundle:Advert:finaux.html.twig', array(

            'listAdverts' => $listAdverts

        ));


    }

    public function menuAction()

    {

        // On fixe en dur une liste ici, bien entendu par la suite

        // on la récupérera depuis la BDD !

        $listAdverts = array(

            array('id' => 2, 'title' => 'Recherche développeur Symfony'),

            array('id' => 5, 'title' => 'Mission de webmaster'),

            array('id' => 9, 'title' => 'Offre de stage webdesigner')

        );


        return $this->render('FirstBundle:Advert:menu.html.twig', array(

            // Tout l'intérêt est ici : le contrôleur passe

            // les variables nécessaires au template !

            'listAdverts' => $listAdverts

        ));

    }



    public function index1Action()

    {
        $content = $this->get('templating')->render('FirstBundle:Advert:index1.html.twig',array('nom'=>'Slassi'));

        return new Response($content);

    }

    public function index3Action()

    {

        $content = $this->get('templating')->render('FirstBundle:Advert:index3.html.twig');

        return new Response($content);

    }

    public function paramAction($id, Request $request)

    {

        // On récupère notre paramètre tag

        $tag = $request->query->get('tag');


        return new Response(

            "Affichage de l'annonce d'id : ".$id.", avec le tag : ".$tag

        );

    }

    public function view0Action($id)
    {

        $advert = array(

            'title'   => 'Recherche développpeur Symfony2',

            'id'      => $id,

            'author'  => 'Alexandre',

            'content' => 'Nous recherchons un développeur Symfony2 débutant sur Lyon. Blabla…',

            'date'    => new \Datetime()

        );


        return $this->render('FirstBundle:Advert:view.html.twig', array(

            'advert' => $advert

        ));

    }

    public function editAction($id, Request $request)

    {

        // ...



        $advert = array(

            'title'   => 'Recherche développpeur Symfony',

            'id'      => $id,

            'author'  => 'Alexandre',

            'content' => 'Nous recherchons un développeur Symfony débutant sur Lyon. Blabla…',

            'date'    => new \Datetime()

        );


        return $this->render('FirstBundle:Advert:edit.html.twig', array(

            'advert' => $advert

        ));

    }


    public function viewSlugAction($slug, $year, $_format)
    {

        return new Response(

            "On pourrait afficher l'annonce correspondant au

            slug '".$slug."', créée en ".$year." et au format ".$format."."

        );

    }


    public function viewAction()

    {

        // On veut avoir l'URL de l'annonce d'id 5.

        $url = $this->get('router')->generate(

            'smile_platform_view', // 1er argument : le nom de la route

            array('id' => 999)    // 2e argument : les valeurs des paramètres

        );

        // $url vaut « /platform/advert/5 »



        return new Response("L'URL de l'annonce d'id 5 est : ".$url);

    }


    public function view3Action($id,Request $request){

        $tag = $request->query->get('tag');

        return $this->render('FirstBundle:Advert:view1.html.twig',array('id'=>$id,'tag'=>$tag));

    }

    public function sessionAction($id,Request $request){

        // Récupération de la session

        $session = $request->getSession();



        // On récupère le contenu de la variable user_id

        $userId = $session->get('user_id');


        // On définit une nouvelle valeur pour cette variable user_id

        $session->set('user_id', 91);


        // On n'oublie pas de renvoyer une réponse

        return new Response("<body>Je suis une page de test, je n'ai rien à dire</body>");
    }





}