<?php

namespace Smile\FirstBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FirstBundle extends Bundle
{
}
