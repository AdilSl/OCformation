<?php

namespace Smile\FirstBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ContControllerTest extends WebTestCase
{
}
