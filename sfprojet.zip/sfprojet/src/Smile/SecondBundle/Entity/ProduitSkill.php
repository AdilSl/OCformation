<?php

namespace Smile\SecondBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ProduitSkill
 *
 * @ORM\Table(name="produit_skill")
 * @ORM\Entity(repositoryClass="Smile\SecondBundle\Repository\ProduitSkillRepository")
 */
class ProduitSkill
{
    /**
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */

    private $id;

    /**
     * @ORM\Column(name="level", type="string", length=255)
     */
    private $level;


    /**
     * @ORM\ManyToOne(targetEntity="Smile\SecondBundle\Entity\Produit")
     * @ORM\JoinColumn(nullable=false)
     */
    private $produit;


    /**
     * @ORM\ManyToOne(targetEntity="Smile\SecondBundle\Entity\Skill")
     * @ORM\JoinColumn(nullable=false)
     */
    private $skill;


    // ... vous pouvez ajouter d'autres attributs bien sûr


    /**

     * @return integer

     */

    public function getId()

    {

        return $this->id;

    }


    /**

     * @param string $level

     */

    public function setLevel($level)

    {

        $this->level = $level;

    }


    /**

     * @return string

     */

    public function getLevel()

    {

        return $this->level;

    }


    /**

     * @param Produit $produit

     */

    public function setProduit(Produit $produit)

    {

        $this->produit = $produit;

    }


    /**

     * @return Produit

     */

    public function getProduit()

    {

        return $this->produit;

    }


    /**

     * @param Skill $skill

     */

    public function setSkill(Skill $skill)

    {

        $this->skill = $skill;

    }


    /**

     * @return Skill

     */

    public function getSkill()

    {

        return $this->skill;

    }
}

