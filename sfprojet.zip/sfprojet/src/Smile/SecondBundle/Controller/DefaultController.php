<?php

namespace Smile\SecondBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Smile\SecondBundle\Entity\Produit;
use Smile\SecondBundle\Entity\Image;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class DefaultController extends Controller
{
    /**
     * @Route("/index/{page}", name="index")
     */
    public function indexAction($page)
    {
        if($page<1){
            throw new NotFoundHttpException('La page // '.$page.'  n\'existe pas');
        }

        // Ici je fixe le nombre d'annonces par page à 3

        // Mais bien sûr il faudrait utiliser un paramètre, et y accéder via $this->container->getParameter('nb_per_page')

        $nbPerPage = 2;


        // On récupère notre objet Paginator


        $listeProduit = $this->getDoctrine()->getManager()->getRepository('SecondBundle:Produit')->getProduit($page, $nbPerPage);

        $nbPages = ceil(count($listeProduit) / $nbPerPage);

        // Si la page n'existe pas, on retourne une 404

        if ($page > $nbPages) {
            throw $this->createNotFoundException("La page *** ".$page." n'existe pas.");
        }

        return $this->render('SecondBundle:Default:pagination.html.twig', array(

            'listeProduit' => $listeProduit,

            'nbPages'     => $nbPages,

            'page'        => $page,

        ));

    }


    /**
     * @Route("/homepage/{page}", name="homepage")
     */
    public function viewAction($id){

        $em = $this->getDoctrine()->getManager();
        $produit=$em->getRepository('SecondBundle:Produit')->find($id);

        if(null === $produit){
            throw new NotFoundHttpException('Le produit de l\'id : '.$id.'  n\'existe pas');
        }

        $listApplication = $em->getRepository('SecondBundle:Application')->findBy(array('produit'=>$produit));

        if(null === $listApplication){
            throw new NotFoundHttpException('Les applications du produit de l\'id : '.$id.'  n\'existe pas');
        }


        $listProduitSkill = $em->getRepository('SecondBundle:ProduitSkill')->findBy(array('produit'=>$produit));

       return $this->render('SecondBundle:Default:select.html.twig',array(
                                                                          'Produit'=>$produit ,
                                                                          'listApplication'=>$listApplication ,
                                                                          'listProduitSkill'=>$listProduitSkill)
                                                                         );

    }


//
//    /**
//     * @Route("/contact", name="contactpage")
//     * @param Request $request
//     * @return \Symfony\Component\HttpFoundation\Response
//     */

    public function flashAction(Request $request0)
    {

        $session = $request0->getSession();

        // Bien sûr, cette méthode devra réellement ajouter l'annonce

        // Mais faisons comme si c'était le cas

        $session->getFlashBag()->add('info', 'Annonce bien enregistrée');


        // Le « flashBag » est ce qui contient les messages flash dans la session

        // Il peut bien sûr contenir plusieurs messages :

        $session->getFlashBag()->add('info', 'Oui oui, elle est bien enregistrée !');

       return $this->render('SecondBundle:Default:contact.html.twig');


    }

    /**
     * @Route("/test", name="test")
     */
    public function testAction()
    {
        return $this->render('SecondBundle:Default:layout.html.twig');
    }



    /**
     * @Route("/add", name="ajouter")
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function addAction(Request $request){

        // Création de l'entité

        $produit = new Produit;

        $produit->setTitle('Recherche développeur Symfony.');

        $produit->setAuthor('Alexandre');

        $produit->setContent("Nous recherchons un développeur Symfony débutant sur Lyon. Blabla…");

        // On peut ne pas définir ni la date ni la publication,

        // car ces attributs sont définis automatiquement dans le constructeur

        // Création de l'entité Image

        $image = new Image();

        $image->setUrl('http://sdz-upload.s3.amazonaws.com/prod/upload/job-de-reve.jpg');

        $image->setAlt('Job de rêve');



        // On lie l'image à l'annonce

        $produit->setImage($image);



        // Étape 1 : On « persiste » l'entité




        // On récupère l'EntityManager

        $em = $this->getDoctrine()->getManager();

        $em->persist($produit);

        // Étape 1 bis : si on n'avait pas défini le cascade={"persist"},

        // on devrait persister à la main l'entité $image

        // $em->persist($image);


        // Étape 2 : On déclenche l'enregistrement

        $em->flush();


        // Reste de la méthode qu'on avait déjà écrit

        if ($request->isMethod('POST')) {




            // Puis on redirige vers la page de visualisation de cettte annonce

            return new Response('lia lgne à été bien ajouter');

        }


        // Si on n'est pas en POST, alors on affiche le formulaire

        return new Response('lia lgne à été bien ajouter');
    }



    /**
     * @Route("/edit/{id}", name="modifier")
     * @param Request $request
     */
    public function editAction($id, Request $request)
    {

        $em = $this->getDoctrine()->getManager();


        // On récupère l'annonce $id

        $pr = $em->getRepository('SecondBundle:Produit')->find($id);


        if (null === $pr) {

            throw new NotFoundHttpException("Le produit d'id ".$id." n'existe pas.");

        }


        // La méthode findAll retourne toutes les catégories de la base de données

        $listCategories = $em->getRepository('SecondBundle:Categorie')->findAll();


        // On boucle sur les catégories pour les lier à l'annonce

        foreach ($listCategories as $categorie) {

            $pr->addCategory($categorie);

        }


        // Pour persister le changement dans la relation, il faut persister l'entité propriétaire

        // Ici, Advert est le propriétaire, donc inutile de la persister car on l'a récupérée depuis Doctrine


        // Étape 2 : On déclenche l'enregistrement

        $em->flush();



        return $this->render('SecondBundle:Default:view.html.twig',array('pr'=>$pr));

        // … reste de la méthode

    }


    /**
     * @Route("/delete/{id}", name="supprimer")
     * @param Request $request
     */
    public function deleteAction($id)
    {

        $em = $this->getDoctrine()->getManager();


        // On récupère l'annonce $id

        $produit = $em->getRepository('SecondBundle:Produit')->find($id);


        if (null === $produit) {

            throw new NotFoundHttpException("le produit d'id ".$id." n'existe pas.");

        }


        // On boucle sur les catégories de l'annonce pour les supprimer

        foreach ($produit->getCategories() as $categorie) {

            $produit->removeCategory($categorie);

        }


        // Pour persister le changement dans la relation, il faut persister l'entité propriétaire

        // Ici, Advert est le propriétaire, donc inutile de la persister car on l'a récupérée depuis Doctrine


        // On déclenche la modification

        $em->flush();


        return  new Response("les categories de produit ".$id." bien étés supprimer");

        // ...

    }

    /**
     * @Route("/selectby/{author}/{id}",name="selectby")
     */
    public function selectbyAction($author,$id)
    {
        $em = $this->getDoctrine()->getManager();
        $produit = $em->getRepository('SecondBundle:Produit')->findOneBy([
            'id' => $id,
            'author' => $author,
        ]);


        if (null === $produit) {
            throw new NotFoundHttpException("le produit ".$author." de l ".$id." n'existe pas.");
        }


        $str = "produit ".$produit->getAuthor()." de l'id : ".$produit->getId()."<br>";


        return new Response($str);
    }

    /**
     * @Route("/selectAll",name="selectAll")
     */
    public function selectAllAction()
    {
        $em = $this->getDoctrine()->getManager();
        $listProduits = $em->getRepository('SecondBundle:Produit')->findAll();

        if (null === $listProduits) {
            throw new NotFoundHttpException("les produits n'existent pas.");
        }

        $str ="";
        foreach($listProduits as $produit){

            $str .= "produit ".$produit->getAuthor()." de l'id : ".$produit->getId()."<br>";
        }


        return new Response($str);
    }


    /**
     * @Route("/selectProduitImage", name="slectPI")
     */
    public function selectPIAction()
    {
        $img = array(4,3);

        $em = $this->getDoctrine()->getManager();
        $listPI = $em->getRepository('SecondBundle:Produit')->getProduitWithImages($img);


        if (null === $listPI) {
            throw new NotFoundHttpException("les produits n'existent pas.");
        }

        return $this->render('SecondBundle:Default:select.html.twig',array('listPI'=>$listPI));

    }

    /**
     * @Route("/menu/{limit}", name="menu")
     */
     public function menuAction($limit)
     {
         $em = $this->getDoctrine()->getManager();
         $listProduit = $em->getRepository('SecondBundle:Produit')->findBy(
             array(),                 // Pas de critère
             array('date' => 'desc'), // On trie par date décroissante
             $limit,                  // On sélectionne $limit annonces
             0                        // À partir du premier
         );

         return $this->render('SecondBundle:Default:view1.html.twig', array(
             'listProduit' => $listProduit
         ));

     }

}
