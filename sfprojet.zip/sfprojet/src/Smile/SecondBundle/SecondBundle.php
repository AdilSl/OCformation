<?php

namespace Smile\SecondBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SecondBundle extends Bundle
{
}
