<?php

namespace OP\CoreBundle\Controller;

use http\Env\Response;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Session\Session;
use OP\CoreBundle\Antispam\OPAntispam;


class AdvertController extends Controller
{




    public function menuAction()
    {
        $listAdverts = array(
            array('id' => 2, 'title' => 'Recherche développeur Symfony'),

            array('id' => 5, 'title' => 'Mission de webmaster'),

            array('id' => 9, 'title' => 'Offre de stage webdesigner')
        );


        return $this->render('FirstBundle:Advert:menu.html.twig', array(
            'listAdverts' => $listAdverts
        ));
    }


    public function contactAction(Request $request)
    {


        $session = new Session();



        $session->getFlashBag()->add('information', 'La page de contact n’est pas encore disponible');


        return $this->render('CoreBundle::layout.html.twig');

    }



    public function serviceAction(Request $request)
    {
        // On récupère le service

        $antispam = $this->container->get('Core.OPAntispam');
        $param = $this->container->getParameter('mailer_host');
        // Je pars du principe que $text contient le texte d'un message quelconque

        $text = '...';

        if ($antispam->isSpam($text)) {

            throw new \Exception('Votre message a été détecté comme spam !  avec paramètre: '.$param);

        }



        // Ici le message n'est pas un spam

        return new Response('le message n est pas un spam');

    }


}
